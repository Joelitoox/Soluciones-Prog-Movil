package com.example.mundo3d;

import com.jme3.app.AndroidHarness;

public class MainActivity extends AndroidHarness {

    public MainActivity() {

        appClass = "com.example.mundo3d.GameMain";

        eglBitsPerPixel = 24;
        eglAlphaBits = 0;
        eglDepthBits = 16;
        eglSamples = 0;

        exitDialogTitle = "Salir";
        exitDialogMessage = "Desea salir del juego?";
    }
}