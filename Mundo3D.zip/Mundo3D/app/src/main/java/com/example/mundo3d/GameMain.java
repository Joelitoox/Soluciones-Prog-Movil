package com.example.mundo3d;

import com.jme3.app.SimpleApplication;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.*;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;
import com.jme3.input.controls.*;
import com.jme3.input.KeyInput;
import com.jme3.texture.Texture;

public class GameMain extends SimpleApplication implements ActionListener {

    private Geometry jugador;

    public static void main(String[] args) {
        GameMain app = new GameMain();
        app.start();
    }

    @Override
    public void simpleInitApp() {

        crearLuz();
        crearSuelo();
        crearJugador();
        configurarCamara();
        configurarControles();
    }

    private void crearLuz(){

        DirectionalLight sol = new DirectionalLight();
        sol.setDirection(new Vector3f(-1,-1,-1));

        rootNode.addLight(sol);
    }

    private void crearSuelo(){

        Box suelo = new Box(20,0.1f,20);

        Geometry terreno = new Geometry("Suelo", suelo);

        Material mat = new Material(assetManager,
                "Common/MatDefs/Misc/Unshaded.j3md");

        try {
            Texture tex = assetManager.loadTexture("Textures/imagenpisojuego.jpg");
            tex.setWrap(Texture.WrapMode.Repeat);
            suelo.scaleTextureCoordinates(new Vector2f(4, 4));
            mat.setTexture("ColorMap", tex);
        } catch (Exception e) {
            mat.setColor("Color", ColorRGBA.Green);
        }

        terreno.setMaterial(mat);

        rootNode.attachChild(terreno);
    }

    private void crearJugador(){

        Box cuerpo = new Box(0.5f,1,0.5f);

        jugador = new Geometry("Jugador", cuerpo);

        Material mat = new Material(assetManager,
                "Common/MatDefs/Misc/Unshaded.j3md");

        mat.setColor("Color", ColorRGBA.Blue);

        jugador.setMaterial(mat);

        jugador.setLocalTranslation(0,1,0);

        rootNode.attachChild(jugador);
    }

    private void configurarCamara(){

        cam.setLocation(new Vector3f(0,6,10));
        cam.lookAt(jugador.getLocalTranslation(), Vector3f.UNIT_Y);
    }

    private void configurarControles(){

        inputManager.addMapping("Izquierda",
                new KeyTrigger(KeyInput.KEY_A));

        inputManager.addMapping("Derecha",
                new KeyTrigger(KeyInput.KEY_D));

        inputManager.addMapping("Adelante",
                new KeyTrigger(KeyInput.KEY_W));

        inputManager.addMapping("Atras",
                new KeyTrigger(KeyInput.KEY_S));

        inputManager.addListener(this,
                "Izquierda","Derecha","Adelante","Atras");
    }

    @Override
    public void onAction(String name, boolean keyPressed, float tpf) {

        if(!keyPressed) return;

        if(name.equals("Izquierda"))
            jugador.move(-1,0,0);

        if(name.equals("Derecha"))
            jugador.move(1,0,0);

        if(name.equals("Adelante"))
            jugador.move(0,0,-1);

        if(name.equals("Atras"))
            jugador.move(0,0,1);
    }
}